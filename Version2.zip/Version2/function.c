//g++ -fPIC -shared -I/usr/include/opencv4 -lopencv_imgproc -lopencv_core -Wall -Wl,-soname,a.so -o a.so function.c
//not working g++ -fPIC -shared function.c -o -ltwocams -lopencv_core -lopencv_imgproc -lopencv_imgcodecs -lopencv_videoio -lz -lwebp -lpthread -ltiff -lpng
//not w g++ function.c -o main -ltwocams -lopencv_core -lopencv_imgproc -lopencv_imgcodecs -lopencv_videoio -lz -lwebp -lpthread -ltiff -lpng




//use this 8 july 2022
//g++ -fPIC -shared function.c -o fn.so -Wl,--no-undefined $( pkg-config opencv4 --cflags --libs)
#include <opencv2/opencv.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <iostream>
#include <chrono>
#include <ctime>
#include <unistd.h>
#include <stdint.h>
#include<string.h>
#include <stdio.h>
#include <stdlib.h>
//#include <Python.h>
#include <wchar.h>
//#include <dlfcn.h>


using namespace std;
using namespace cv;
Mat frame,Matrix , framePerv,frameGray,frameThresh,frameEdge, frameFinal;
Mat ROIlane,frameFinaldup,frameFinaldup1,ROIlaneend;
int LeftLanePos, RightLanePos,laneCentre,frameCentre,Result;
vector<int> histogramLane;
vector<int> histogramLaneEnd;
stringstream ss;
int flag=0;
int laneEnd;
int lane1,lane2;
int command; //for logging
// creating a point of intrest 
Point2f Source[] = {Point2f(40,180),Point2f(295,180),Point2f(8,220),Point2f(325,220)};
Point2f Destination[] = {Point2f(60,0),Point2f(270,0),Point2f(60,240),Point2f(270,240)};





extern "C" void imgread(unsigned char* framedata) // working
{
  //dlopen("plugin.so", RTLD_NOW | RTLD_GLOBAL);
  cv::Mat frame(cv::Size(1280,720), CV_8UC3, framedata);
  //cout<<"laneCentre - frameCentre="<<endl;
   /*Do something*/
   //return 1;
}





//extern "C" int myFunction2(Mat frame)
extern "C" int myFunction2(unsigned char* framedata)
{
	cv::Mat frame(cv::Size(360,240), CV_8UC3, framedata);//CV_8UC3 ,means RGB
	//cv::namedWindow( "Display window", cv::WINDOW_AUTOSIZE );
	//cv::imshow( "Display window", frame);
	//cv::waitKey(10000);
	
	
	//Persecpective();
	line(frame,Source[0],Source[1],Scalar(0,0,255),2);
	line(frame,Source[1],Source[3],Scalar(0,0,255),2);
	line(frame,Source[3],Source[2],Scalar(0,0,255),2);
	line(frame,Source[2],Source[0],Scalar(0,0,255),2);
	Matrix =getPerspectiveTransform(Source,Destination);
	warpPerspective(frame,framePerv,Matrix,Size(360,240));	
	
	
	//Threshold();
	cvtColor(framePerv,frameGray,COLOR_RGB2GRAY);
	inRange(frameGray,240,255,frameThresh);
	Canny(frameGray,frameEdge,800,900,3,false);
	add(frameEdge,frameThresh,frameFinal);
	cvtColor(frameFinal,frameFinal,COLOR_GRAY2RGB);
	cvtColor(frameFinal,frameFinaldup,COLOR_RGB2BGR);
	cvtColor(frameFinal,frameFinaldup1,COLOR_RGB2BGR);
    
    
	//Histogram();
	histogramLane.resize(360);
    	histogramLane.clear();
    	for(int i=0;i<frame.size().width;i++){ 	
		ROIlane = frameFinaldup(Rect(i,140,1,100));  
		divide(255,ROIlane,ROIlane);
		histogramLane.push_back((int)(sum(ROIlane)[0]));
    	}		
    	histogramLaneEnd.resize(360);
    	histogramLaneEnd.clear();
    	for(int i=0;i<frame.size().width;i++){ 	
		ROIlaneend = frameFinaldup1(Rect(i,0,1,240)); 
		divide(255,ROIlaneend,ROIlaneend);
		histogramLaneEnd.push_back((int)(sum(ROIlaneend)[0]));
    	}	
	laneEnd= sum(histogramLaneEnd)[0];
	  	  
	  
	//laneFinder();
	vector<int>:: iterator LeftPtr;
    	LeftPtr = max_element(histogramLane.begin(), histogramLane.begin()+180);
	LeftLanePos =distance (histogramLane.begin(),LeftPtr);
	vector<int>:: iterator RightPtr;
	RightPtr = max_element(histogramLane.begin()+180, histogramLane.end());
	RightLanePos =distance (histogramLane.begin(),RightPtr);
	line(frameFinal ,Point2f(LeftLanePos,0),Point2f(LeftLanePos,240),Scalar(0,255,0),2);
	line(frameFinal ,Point2f(RightLanePos,0),Point2f(RightLanePos,240),Scalar(0,255,0),2);
          
    
	//lanecentre();
	laneCentre = (RightLanePos -LeftLanePos) /2 + LeftLanePos;
	frameCentre = 164;
	line(frameFinal , Point2f(laneCentre,0) ,Point2f(laneCentre,240),Scalar(0,255,0),3);
	line(frameFinal , Point2f(frameCentre,0) ,Point2f(frameCentre,240),Scalar(255,0,0),3);
	Result = laneCentre - frameCentre;
	
	/*
	if( Result ==0){   
		cout<<"Result="<<Result<<"	Forward "<<endl;
    	}
   	else if(Result >0 && Result <10){
		cout<<"Result="<<Result<<"	Right1 "<<endl;
    	} 
   	else if(Result <0 && Result > -10){
		cout<<"Result="<<Result<<"	Left1 "<<endl;
    	}
   	else {
    	cout<<"Result="<<Result<<"	stop"<<endl;	
   	}   
   	*/
   
   	if (laneEnd < 300){
	    ss.str(" ");
	    ss.clear();
	    ss<<"Lane End Detected:  "<<laneEnd <<"Forward";
	    putText(frame,ss.str(),Point2f(1,50),0,1,Scalar(255,0,255),2);
	}	
    	if( Result ==0){
	    ss.str(" ");
	    ss.clear();
	    ss<<"Result  "<<Result <<"Forward";
	    putText(frame,ss.str(),Point2f(1,50),0,1,Scalar(0,0,255),2);
	}
	if( Result >0){
	    ss.str(" ");
	    ss.clear();
	    ss<<"Result  "<<Result <<"Right";
	    putText(frame,ss.str(),Point2f(1,50),0,1,Scalar(0,255,0),2);
	}
	if( Result <0){
	    ss.str(" ");
	    ss.clear();
	    ss<<"Result  "<<Result <<"Left";
	    putText(frame,ss.str(),Point2f(1,50),0,1,Scalar(255,0,0),2);
	}
    
	namedWindow("original",WINDOW_KEEPRATIO);
	moveWindow("original",0,600);
	resizeWindow("original",640,480);
	imshow("original", frame);

	namedWindow("Persp",WINDOW_KEEPRATIO);
	moveWindow("Persp", 640,100);
	resizeWindow("Persp",640,480);
	imshow("Persp",framePerv);

	namedWindow("Final",WINDOW_KEEPRATIO);
	moveWindow("Final", 1280,100);
	resizeWindow("Final",640,480);
	imshow("Final",frameFinal);
	cv::waitKey(1000);
       
	//display
	//cv::namedWindow( "Display window", cv::WINDOW_AUTOSIZE );
	//cv::imshow( "Display window", frameFinal);
	//cv::waitKey(10000);
	
	return Result;
}






