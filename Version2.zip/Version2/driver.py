# 24 Aug 2022 command to run this code: python3 driver.py
import cv2
import os
import ctypes 
import numpy
import time
import sys
import os.path
import itertools 
from itertools import islice

sys.path.append("../")
from pathlib import Path
sourcedir=Path(__file__).resolve().parent.parent
sourcedir=os.path.join(sourcedir, 'Version2')
sys.path = [sourcedir] + sys.path
#import Enforcer
import Automata
import copy
import collections
import random
import numpy
import time
import pandas as pd 

so_file=sourcedir+"/fn.so"
print(so_file)
fun = ctypes.CDLL(so_file) 
# https://stackoverflow.com/questions/55184278/passing-image-from-python-wrapper-to-a-c-function

#scriptdir = os.path.abspath(os.path.dirname(__file__)); 
#libpath = os.path.join(scriptdir, 'fn.so')
#print(libpath)

#property
phi = Automata.DFA(
    # Input alphabets
    ['r', 'l', 'f', 's'],
    # states
    ['stop', 'start', 'right', 'left', 'forward', 'dead'],
    'start',
    lambda q: q in ['stop'],
    lambda q, a: {
        ('start', 'r'): 'right',
        ('start', 'l'): 'left',
        ('start', 'f'): 'forward',
        ('start', 's'): 'stop',
        ('right', 'r'): 'right',
        ('right', 'l'): 'left',
        ('right', 'f'): 'forward',
        ('right', 's'): 'stop',
        ('left', 'r'): 'right',
        ('left', 'l'): 'left',
        ('left', 'f'): 'forward',
        ('left', 's'): 'stop',
        ('forward', 'r'): 'right',
        ('forward', 'l'): 'left',
        ('forward', 'f'): 'forward',
        ('forward', 's'): 'stop',
        ('stop', 'r'): 'dead',
        ('stop', 'l'): 'dead',
        ('stop', 'f'): 'dead',
        ('stop', 's'): 'dead',
	('dead', 'r'): 'dead',
        ('dead', 'l'): 'dead',
        ('dead', 'f'): 'dead',
        ('dead', 's'): 'dead',
    }[(q, a)]
)

#### Function to pre-compute emptiness check for each state in the given automaton ###############
def computeEmptinessDict(autC):
    dictEnf = {}
    for state in autC.Q:
        autC.makeInit(state) 
        if autC.isEmpty():
            dictEnf[state] = True
        else:
            dictEnf[state] = False
    return dictEnf
    
#### Function to compute substring of sigmaC by removing smallest cycle in sigmaC ###############
def computes_substring(iterable, n,automata,k):
	cleanedBuffer=[]
	automata.reset(k)
	p1=k
	for i in range (len(iterable)-n): #0, 1, 2, 3, 4, 5
		element=list(islice(iterable[i:], 0, 1+n, 1))	
		for j in range(n+1):
			p2=automata.step1(element[j])
			if(j==0):
				p3=p2
		if(p2==p1):
			cleanedBuffer.extend(iterable[i+n+1:])#cleanedBuffer+iterable[i+n+1:]
			return [n+1,cleanedBuffer];   
		else:
			cleanedBuffer.append(element[0])
		p1=p3
		automata.makeInit(p3)
		automata.reset(p1)

#### Function returning cleaned sigmaC #########################################################
def clean(sigmaC,phiautomata,maxBuffer,k,event):
	yn=None
	for i in range(len(sigmaC)) :
		if(yn == None):
			yn=computes_substring(list(sigmaC),i,phiautomata,k) #compute\_substring    # list() tc is o(n)
			if(i==0 and yn == None):
				for t in sigmaC:
					q_q = phiautomata.d(k, t)
				if phiautomata.d(q_q, event) == q_q:
					return sigmaC
	if(yn!=None):
		yn=yn[1:]
		yn = list(itertools.chain(*yn))
		yn.append(event)
		return yn     
    
    
    
#needed for ideal
"""
isigmaC= []
isigmaS=[]
init_i=phi.q0
ip=phi.q0
dictEnf = computeEmptinessDict(phi)
"""

#needed for bounded
maxBuffer=2
"""
if maxBuffer < len(phi.Q):
	print('your buffer is not of reasonable size')
	exit() 
"""
sigmaC = collections.deque([] * maxBuffer, maxlen=maxBuffer)
sigmaS=[]
q=phi.q0
dictEnf = computeEmptinessDict(phi)
phi.q0=q
m=q

	
for i in range(0,100):
	filename=sourcedir+"/images/file_"+str(i+1)+".JPG"
	print("image_"+str(i+1))
	img = cv2.imread(filename)
	height, width = img.shape[:2]
	testarray1 = numpy.fromstring(img, numpy.uint8) 
	testarray2 = numpy.reshape(testarray1, (240, 360, 3))
	framearray = testarray2.tostring()
	Result=fun.myFunction2(framearray)
	print(Result)
	if(Result ==0):
		Command="f" #Forward
		print("Forward")
	elif(Result >0 and Result <10):
		Command="r" #Right
		print("Right")
	elif(Result <0 and Result > -10):
		Command="l" #Left
		print("Left")
	else:
		Command="s" #Stop
		print("Stop")
	"""
	#######################################	Ideal enforcer		#################################	
	a=ip # a keeps initial state
	ip=phi.step1(Command)
	if phi.F(ip):
		Final=True
		phi.reset(init_i)
		phi.makeInit(init_i)
		ip=init_i
		a=ip		
	else:
		Final=False
	if Final == True:
		for e in isigmaC:
			isigmaS.append(e)
		isigmaS.append(Command)
		isigmaC= []
		print("output sequence is "+ str(isigmaS))
		isigmaS= []
	else:
		if dictEnf[ip] == True:
			ip=a
		else:
			isigmaC.append(Command)
			a=ip
	######################################       Ideal enforcer ends	################################
	"""




	
	##################################	Bounded enforcer	####################################
	t=q		#t holds initial state
	q = phi.d(q, Command);print(q)
	if phi.F(q):
		Final=True
	else:
		Final=False
	if Final == True:
    		for a in sigmaC:
        		sigmaS.append(a)
    		sigmaS.append(Command)
    		sigmaC= []
    		t=q	#t holds new current state
    		print("output sequence is "+ str(sigmaS));sigmaS=[]
    		phi.q0=m;q=m
	else:
		if dictEnf[q] == True:
			q=t	#event is suppressed
		else:
			t=q
			if len(sigmaC) >=maxBuffer:	## len tc is o(n)
				
				phi.q0=m
				k=phi.q0		
				for t in sigmaS:
					k=phi.d(k, t)
				#y=y+1
				sigmaC1=clean(sigmaC,phi,maxBuffer,k,Command)
				print("ccccccllllleeeeeaaaaannnn")
				if sigmaC1==100:
					break
				else:
					sigmaC=sigmaC1
			else:
				sigmaC.append(Command)              		
	print("##########################################################################")
	#print("output sequence is "+ str(sigmaS))#comment this while running GeneratePasswordPerformanceEval.py
	##################################	Bounded enforcer ends	####################################

	
  




